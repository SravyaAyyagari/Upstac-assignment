package org.upgrad.upstac.testrequests.consultation;

public enum DoctorSuggestion {
    NO_ISSUES,HOME_QUARANTINE,ADMIT
}
